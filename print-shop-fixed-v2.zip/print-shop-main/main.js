const { app, BrowserWindow, BrowserView, ipcMain, dialog, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const crypto = require('crypto');
const os = require('os');
const { pathToFileURL } = require('url');
const Store = require('electron-store');
const { PDFDocument } = require('pdf-lib');
const {
  print: printPdfSilently,
  getPrinters: getSystemPrinters,
  getDefaultPrinter
} = require('pdf-to-printer');

const store = new Store({
  defaults: { presets: [], history: [], language: 'en', theme: 'dark' }
});

// Layout constants (px) — space reserved above the BrowserView for our custom UI
const TABBAR_HEIGHT = 40;
const TOOLBAR_HEIGHT = 52;
const BASE_TOP_OFFSET = TABBAR_HEIGHT + TOOLBAR_HEIGHT;
let extraTopOffset = 0; // grows when the "more settings" row is expanded, set via IPC
const LARGE_FILE_WARNING_PAGES = 50;

let mainWindow = null;
/** @type {Map<string, {view: BrowserView|null, filePath: string, title: string, pageCount: number, printer: string|null, locked: boolean, bw: boolean, pinned?: boolean, hidden?: boolean, lastAccess?: number}>} */
const tabs = new Map();
let activeTabId = null;
let tabCounter = 0;
let pendingFileToOpen = null; // a .pdf passed on the command line before the window exists

// Limit number of live BrowserViews to avoid high memory use. Other tabs are
// lazy-loaded when activated. Tune as needed.
const MAX_ACTIVE_VIEWS = 3;

// ---------- Single instance / "open with" support ----------
// When the app is set as the default PDF handler, Windows launches a new
// process with the file path as an argv — we forward that into the already
// running window instead of opening a second app.
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (event, argv) => {
    const filePath = argv.find((a) => a.toLowerCase().endsWith('.pdf') && fs.existsSync(a));
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
      if (filePath) createTab(filePath);
    } else if (filePath) {
      // Window not ready yet — remember the file, opened in did-finish-load
      pendingFileToOpen = filePath;
    }
  });
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    },
    title: 'Print Shop'
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  mainWindow.webContents.once('did-finish-load', () => {
    const argFile = process.argv.find((a) => a.toLowerCase().endsWith('.pdf'));
    const fileToOpen = pendingFileToOpen || argFile;
    if (fileToOpen && fs.existsSync(fileToOpen)) {
      createTab(fileToOpen);
    }
  });

  mainWindow.on('resize', () => layoutActiveView());

  buildMenu();
}

function layoutActiveView() {
  if (!activeTabId) return;
  const tab = tabs.get(activeTabId);
  if (!tab) return;
  const bounds = mainWindow.getContentBounds();
  const offset = BASE_TOP_OFFSET + extraTopOffset;
  tab.view.setBounds({
    x: 0,
    y: offset,
    width: bounds.width,
    height: Math.max(0, bounds.height - offset)
  });
}

function sendToRenderer(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, payload);
  }
}

function serializeTabs() {
  // Include filePath and originalFilePath so renderer can decide which tabs to show
  return Array.from(tabs.entries()).map(([id, t]) => ({
    id,
    title: t.title,
    filePath: t.filePath || null,
    originalFilePath: t.originalFilePath || null,
    pageCount: t.pageCount,
    printer: t.printer,
    locked: t.locked,
    bw: t.bw,
    isPreview: !!t.isPreview,
    pinned: !!t.pinned,
    hidden: !!t.hidden,
    active: id === activeTabId
  }));
}

function broadcastTabs() {
  sendToRenderer('tabs-updated', { tabs: serializeTabs(), totalPages: getTotalPages() });
}

// Fast page count: scan raw bytes for "/Type /Page" markers instead of
// building pdf-lib's full object graph. This is what previously froze the
// whole app ("Not Responding") on big PDFs — it ran on the Main process,
// which is single-threaded, so any heavy synchronous work blocks the UI.

async function getPageCountFast(filePath) {
  // Offload counting to a child Node process that streams the file so the
  // main event loop isn't blocked by large-memory allocations or heavy regex.
  return new Promise((resolve) => {
    const workerScript = path.join(__dirname, 'pageCountWorker.js');
    // ELECTRON_RUN_AS_NODE is critical: without it, in a packaged build
    // process.execPath is the app's own .exe, which would launch a second
    // GUI instance — triggering 'second-instance' with the PDF path in argv
    // and opening duplicate tabs in an endless loop.
    execFile(process.execPath, [workerScript, filePath], {
      timeout: 15000,
      windowsHide: true,
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }
    }, (err, stdout) => {
      if (err) {
        // Fallback: try lightweight pdf-lib method
        fs.promises.readFile(filePath).then((buffer) => {
          PDFDocument.load(buffer, { ignoreEncryption: true }).then((doc) => resolve(doc.getPageCount())).catch(() => resolve(0));
        }).catch(() => resolve(0));
        return;
      }
      try {
        const parsed = JSON.parse(stdout);
        if (parsed && typeof parsed.count === 'number' && parsed.count > 0) return resolve(parsed.count);
        // fallback
        fs.promises.readFile(filePath).then((buffer) => {
          PDFDocument.load(buffer, { ignoreEncryption: true }).then((doc) => resolve(doc.getPageCount())).catch(() => resolve(0));
        }).catch(() => resolve(0));
      } catch (e) {
        resolve(0);
      }
    });
  });
}

async function createTab(filePath, options = {}) {
  if (!filePath || !fs.existsSync(filePath)) return null;

  const id = `tab-${++tabCounter}`;
  const title = options.title || path.basename(filePath);

  let defaultPrinterName = options.printer || null;
  if (!defaultPrinterName) {
    try {
      const defaultPrinter = await getDefaultPrinter();
      defaultPrinterName = defaultPrinter ? defaultPrinter.name : null;
    } catch (e) {
      // no default printer configured — user must pick one
    }
  }

  // Store both original source path and current filePath (current may be a preview)
  tabs.set(id, {
    view: null, // created lazily by switchTab so the MAX_ACTIVE_VIEWS limit is enforced
    originalFilePath: filePath,
    filePath,
    title,
    pageCount: 0, // filled in asynchronously below, off the critical path
    printer: defaultPrinterName,
    locked: false,
    bw: false,
    pinned: false,
    hidden: false,
    lastAccess: Date.now()
  });

  await switchTab(id);
  broadcastTabs();

  getPageCountFast(filePath).then((count) => {
    const t = tabs.get(id);
    if (t) {
      t.pageCount = count;
      broadcastTabs();
    }
  });

  return id;
}

async function switchTab(id) {
  const tab = tabs.get(id);
  if (!tab) return;

  // Remove current view if present
  if (activeTabId && tabs.has(activeTabId)) {
    const prev = tabs.get(activeTabId);
    if (prev && prev.view) {
      try {
        mainWindow.removeBrowserView(prev.view);
      } catch (e) {}
    }
  }

  activeTabId = id;

  // If new tab doesn't have an active BrowserView, create and load it lazily.
  if (!tab.view) {
    // Enforce max active views by evicting least recently used non-active view
    const activeViews = Array.from(tabs.values()).filter(t => t.view);
    if (activeViews.length >= MAX_ACTIVE_VIEWS) {
      // find LRU view that's not pinned and not the tab we're activating
      let lruId = null; let lruTime = Infinity;
      for (const [tid, tdata] of tabs.entries()) {
        if (tdata.view && tid !== id && !tdata.pinned) {
          const at = tdata.lastAccess || 0;
          if (at < lruTime) { lruTime = at; lruId = tid; }
        }
      }
      if (lruId) {
        const evicted = tabs.get(lruId);
        try { mainWindow.removeBrowserView(evicted.view); } catch (e) {}
        try { evicted.view.webContents.destroy(); } catch (e) {}
        evicted.view = null;
      }
    }

    const view = new BrowserView({ webPreferences: { plugins: true, contextIsolation: true, backgroundThrottling: true } });
    tab.view = view;
    mainWindow.addBrowserView(view);
    // Load file URL — pathToFileURL correctly escapes spaces, '#', '%'
    // and non-ASCII (e.g. Arabic) characters in filenames.
    try {
      view.webContents.loadURL(pathToFileURL(tab.filePath).href);
    } catch (e) {
      console.error('Failed to load PDF in BrowserView:', e);
    }
  } else {
    try { mainWindow.addBrowserView(tab.view); } catch (e) {}
  }

  tab.lastAccess = Date.now();
  layoutActiveView();
  broadcastTabs();
}

function closeTab(id) {
  const tab = tabs.get(id);
  if (!tab || tab.locked) return false;

  try {
    mainWindow.removeBrowserView(tab.view);
  } catch (e) {}
  try {
    tab.view.webContents.destroy();
  } catch (e) {}
  tabs.delete(id);

  if (activeTabId === id) {
    activeTabId = null;
    const remaining = Array.from(tabs.keys());
    if (remaining.length > 0) {
      switchTab(remaining[remaining.length - 1]);
    }
  }
  broadcastTabs();
  return true;
}

async function duplicateTab(id) {
  const tab = tabs.get(id);
  if (!tab) return null;
  // Prefer duplicating the original source file, not a temporary preview
  const source = tab.originalFilePath || tab.filePath;
  return createTab(source, { title: tab.title, printer: tab.printer });
}

function toggleLock(id) {
  const tab = tabs.get(id);
  if (!tab) return;
  tab.locked = !tab.locked;
  broadcastTabs();
}

function togglePin(id) {
  const tab = tabs.get(id);
  if (!tab) return;
  tab.pinned = !tab.pinned;
  broadcastTabs();
}

function hideTab(id) {
  const tab = tabs.get(id);
  if (!tab) return;
  tab.hidden = true;
  // If active, detach its view from the window BEFORE clearing activeTabId
  // (previously activeTabId was nulled first, so switchTab's cleanup never
  // ran and the "hidden" tab's BrowserView stayed visible on screen).
  if (activeTabId === id) {
    if (tab.view) {
      try { mainWindow.removeBrowserView(tab.view); } catch (e) {}
    }
    activeTabId = null;
    for (const [tid, t] of tabs.entries()) {
      if (!t.hidden) { switchTab(tid); break; }
    }
  }
  broadcastTabs();
}

function unhideAllTabs() {
  for (const t of tabs.values()) t.hidden = false;
  broadcastTabs();
}

async function setTabBlackAndWhite(id, bw) {
  const tab = tabs.get(id);
  if (!tab) return;
  tab.bw = bw;
  try {
    if (bw) {
      tab.bwCssKey = await tab.view.webContents.insertCSS(
        'html { filter: grayscale(100%) !important; }'
      );
    } else if (tab.bwCssKey) {
      await tab.view.webContents.removeInsertedCSS(tab.bwCssKey);
      tab.bwCssKey = null;
    }
  } catch (e) {
    // view may still be loading — ignore, this is a cosmetic preview only
  }
  broadcastTabs();
}

function getTotalPages() {
  let sum = 0;
  for (const t of tabs.values()) sum += t.pageCount || 0;
  return sum;
}

function addHistoryEntry(entry) {
  const history = store.get('history');
  history.unshift({ ...entry, timestamp: new Date().toISOString() });
  store.set('history', history.slice(0, 500));
}

// ---------- Advanced printer config: Pages-per-sheet + literal DPI ----------
// Konica Minolta bizhub C458 (Universal V4 PCL driver) uses custom XML namespaces
// for PrintTicket options. Generic names like "PagesPerSheet" don't work.
// This function builds the exact PrintTicketXML structure that Konica's driver expects:
// - Combination feature for N-up (2in1, 4in1, etc.)
// - psf:ParameterInit for Resolution (600dpi/1200dpi)
// Based on actual Get-PrintConfiguration output from the user's driver.
function runPowerShell(command, timeout = 8000) {
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', command],
      { timeout, windowsHide: true },
      (err, stdout, stderr) => resolve({ err, stdout: stdout || '', stderr: stderr || '' })
    );
  });
}

async function applyAdvancedPrinterConfig(printerName, { pagesPerSheet, dpi, duplexingMode }) {
  const needTicket = (pagesPerSheet && pagesPerSheet > 1) || (dpi && dpi > 0);
  if (!needTicket && !duplexingMode) {
    return { ok: true, skipped: true };
  }
  // Escape for single-quoted PowerShell string: double any single quotes
  const psName = printerName.replace(/'/g, "''");

    // Build Konica-specific PrintTicket XML
    // Reference: User's actual PrintTicketXML from Get-PrintConfiguration
    let xmlParts = [
      '<?xml version="1.0"?>',
      '<psf:PrintTicket xmlns:psf="http://schemas.microsoft.com/windows/2003/08/printing/printschemaframework"',
      ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
      ' xmlns:xsd="http://www.w3.org/2001/XMLSchema"',
      ' xmlns:ns0000="http://schemas.konicaminolta.jp/windows/printing/2006/09/PrintTicketExt"',
      ' version="1">'
    ];

    // Add Combination (N-up) setting if specified
    if (pagesPerSheet && pagesPerSheet > 1) {
      const comboValue = pagesPerSheet === 2 ? '2in1' : 
                         pagesPerSheet === 4 ? '4in1' : 
                         pagesPerSheet === 6 ? '6in1' : 
                         pagesPerSheet === 9 ? '9in1' : '16in1';
      xmlParts.push(
        `<psf:Feature name="Combination">`,
        `<psf:Option name="${comboValue}" selected="yes">`,
        `</psf:Option>`,
        `</psf:Feature>`
      );
    }

    // Add Resolution (DPI) setting if specified
    if (dpi && dpi > 0) {
      // Konica uses ParameterInit with Name="Resolution" and Value attribute
      xmlParts.push(
        `<psf:Feature name="DeviceSettings">`,
        `<psf:ParameterInit name="Resolution">`,
        `<psf:Value xsi:type="xsd:string">${dpi}dpi</psf:Value>`,
        `</psf:ParameterInit>`,
        `</psf:Feature>`
      );
    }

  xmlParts.push('</psf:PrintTicket>');
  const printTicketXml = xmlParts.join('');

  // NOTE: the previous implementation built a PowerShell here-string (@"..."@)
  // and then flattened it onto one line with .replace(/\n/g, '; ') — but a
  // here-string terminator MUST start on its own line, so PowerShell threw a
  // parse error 100% of the time and N-up / DPI silently never applied.
  // Writing the XML to a temp file and reading it with Get-Content avoids
  // all quoting/newline pitfalls.
  const stamp = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const ticketPath = path.join(os.tmpdir(), `print-shop-ticket-${stamp}.xml`);
  const backupPath = path.join(os.tmpdir(), `print-shop-ticket-backup-${stamp}.xml`);

  if (needTicket) {
    try {
      await fs.promises.writeFile(ticketPath, printTicketXml, 'utf8');
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  }

  // Best-effort backup of the printer's current config so we can restore it
  // after the job — Set-PrintConfiguration changes the GLOBAL printer default
  // and would otherwise leak into every other application.
  await runPowerShell(
    `$ErrorActionPreference='SilentlyContinue'; ` +
    `$c = Get-PrintConfiguration -PrinterName '${psName}'; ` +
    `if ($c -and $c.PrintTicketXml) { Set-Content -LiteralPath '${backupPath}' -Value $c.PrintTicketXml -Encoding UTF8 }`
  );

  const cleanup = () => {
    try { fs.unlinkSync(ticketPath); } catch (e) {}
    try { fs.unlinkSync(backupPath); } catch (e) {}
  };

  const restore = async () => {
    if (fs.existsSync(backupPath)) {
      await runPowerShell(
        `$ErrorActionPreference='SilentlyContinue'; ` +
        `$xml = Get-Content -Raw -LiteralPath '${backupPath}'; ` +
        `Set-PrintConfiguration -PrinterName '${psName}' -PrintTicketXml $xml`
      );
    }
    cleanup();
  };

  let lastError = null;

  if (needTicket) {
    const res = await runPowerShell(
      `$ErrorActionPreference='Stop'; ` +
      `$xml = Get-Content -Raw -LiteralPath '${ticketPath}'; ` +
      `Set-PrintConfiguration -PrinterName '${psName}' -PrintTicketXml $xml`
    );
    if (res.err) lastError = (res.stderr || String(res.err)).slice(0, 400);
  }

  // Duplex via the documented, vendor-neutral -DuplexingMode parameter.
  // SumatraPDF's duplexshort/duplexlong flags are ignored by some drivers
  // (notably short-edge), so we also set the printer default for the job
  // and restore it afterwards. Values: TwoSidedLongEdge | TwoSidedShortEdge.
  if (duplexingMode) {
    const res = await runPowerShell(
      `$ErrorActionPreference='Stop'; ` +
      `Set-PrintConfiguration -PrinterName '${psName}' -DuplexingMode ${duplexingMode}`
    );
    if (res.err && !lastError) lastError = (res.stderr || String(res.err)).slice(0, 400);
  }

  if (lastError && needTicket) {
    // Ticket application failed — restore and report so the UI can warn
    await restore();
    return { ok: false, error: lastError };
  }
  // Duplex-only failure is non-fatal (Sumatra's own flag may still work);
  // keep the restore handle so any partial change is undone after printing.
  return { ok: true, restore, warning: lastError || null };
}

const PRINT_LOG_PATH = path.join(os.tmpdir(), 'print-shop-print.log');

async function printTab(id, options) {
  const tab = tabs.get(id);
  if (!tab) return { ok: false, error: 'Tab not found' };

  const printerName = options.printer;
  if (!printerName) {
    return { ok: false, error: 'No printer selected for this tab' };
  }

  // Always print from the original source, regenerating transformations
  // from the CURRENT options — the on-screen preview may be stale.
  const sourcePath = (tab.isPreview && tab.originalFilePath) ? tab.originalFilePath : tab.filePath;
  const pagesPerSheet = parseInt(options.pagesPerSheet, 10) || 1;
  const customRange = (options.pagesMode === 'custom' && options.pageRangeText) ? options.pageRangeText : null;

  // ---- Software N-up ----
  // The driver PrintTicket route needs Administrator rights AND
  // vendor-specific XML, so on most setups "pages per sheet" silently did
  // nothing. Instead we compose the N-up sheets ourselves with pdf-lib and
  // print the composed document — what you see in the preview is exactly
  // what prints, on any printer, without elevation.
  let pathToPrint = sourcePath;
  let pagesCountForJob = tab.pageCount || 0;
  let nupApplied = false;
  if (pagesPerSheet > 1) {
    try {
      const nup = await createNupPreview(sourcePath, pagesPerSheet, customRange, 2000);
      if (nup && nup.path) {
        pathToPrint = nup.path;
        pagesCountForJob = nup.sheets; // batching operates on composed sheets
        nupApplied = true;
      }
    } catch (e) {
      fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - software n-up failed, falling back to driver: ${String(e)}\n`);
    }
  }

  let advancedWarning = null;
  const advResult = await applyAdvancedPrinterConfig(printerName, {
    // Driver-level N-up only as a fallback when software compose failed
    pagesPerSheet: nupApplied ? 0 : options.pagesPerSheet,
    dpi: options.dpi,
    duplexingMode: options.duplex
      ? (options.duplexFlip === 'short' ? 'TwoSidedShortEdge' : 'TwoSidedLongEdge')
      : null
  });
  if (!advResult.ok) advancedWarning = advResult.error;
  else if (advResult.warning) advancedWarning = advResult.warning;

  try {

  const printOptions = {
    printer: printerName,
    monochrome: options.color === false,
    side: options.duplex
      ? options.duplexFlip === 'short'
        ? 'duplexshort'
        : 'duplexlong'
      : 'simplex',
    scale: options.scaleMode === 'default' ? 'noscale' : 'fit'
  };
  if (options.paperSize) printOptions.paperSize = options.paperSize;
  // When N-up was composed in software the page range is already applied
  // inside the composed document — do NOT pass it again to the printer.
  if (!nupApplied && customRange) {
    printOptions.pages = customRange;
  }
  printOptions.copies = Math.max(1, parseInt(options.copies, 10) || 1);

  const pagesCount = pagesCountForJob;

  // Log attempt
  try {
    fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - Printing ${tab.title} to ${printerName} (path: ${pathToPrint}) with options ${JSON.stringify(printOptions)}\n`);
  } catch (e) {}

  // If document is very large, print in batches to avoid driver/app memory spikes
  const SPLIT_PRINT_THRESHOLD = 500; // pages above this use batched printing
  const PRINT_BATCH_SIZE = 200;

  // If user requested a custom page selection (and it wasn't already baked
  // into a software N-up compose), respect it and do not auto-split
  const userSpecifiedPages = !nupApplied && customRange;

  if (!userSpecifiedPages && pagesCount > SPLIT_PRINT_THRESHOLD) {
    try {
      // Print copies as the OUTER loop with copies:1 per batch — otherwise
      // multi-copy output comes out as (pages 1-200 xN, 201-400 xN, ...)
      // instead of N collated sets.
      const totalCopies = printOptions.copies;
      for (let copy = 1; copy <= totalCopies; copy++) {
        for (let start = 1; start <= pagesCount; start += PRINT_BATCH_SIZE) {
          const end = Math.min(pagesCount, start + PRINT_BATCH_SIZE - 1);
          const batchOptions = Object.assign({}, printOptions, { pages: `${start}-${end}`, copies: 1 });
          fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - Printing copy ${copy}/${totalCopies} batch ${start}-${end}\n`);
          await printPdfSilently(pathToPrint, batchOptions);
          // small pause between batches to give spooler time
          await new Promise(r => setTimeout(r, 300));
        }
      }
      addHistoryEntry({
        fileName: tab.title,
        printer: printerName,
        pages: pagesCount,
        copies: printOptions.copies
      });
      fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - batched print succeeded\n`);
      return { ok: true, advancedWarning, batched: true };
    } catch (e) {
      const errMsg = String(e && e.message ? e.message : e);
      fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - batched print failed: ${errMsg}\n`);
      // Fall through to attempt single-shot fallback below
    }
  }

  // Single-shot print path (original behavior)
  try {
    await printPdfSilently(pathToPrint, printOptions);
    addHistoryEntry({
      fileName: tab.title,
      printer: printerName,
      pages: pagesCount,
      copies: printOptions.copies
    });
    fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - printPdfSilently succeeded\n`);
    return { ok: true, advancedWarning };
  } catch (e) {
    const errMsg = String(e && e.message ? e.message : e);
    fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - printPdfSilently failed: ${errMsg}\n`);
    console.error('pdf-to-printer failed:', errMsg);

    // Primary print method failed — attempt fallback using BrowserView's print
    if (tab.view && tab.view.webContents) {
      try {
        // Load the exact file we intended to print into the view first
        if (pathToPrint !== tab.filePath) {
          try {
            await tab.view.webContents.loadURL(pathToFileURL(pathToPrint).href);
            // give the renderer a moment to settle
            await new Promise(r => setTimeout(r, 200));
          } catch (eLoad) {
            // ignore load failure and attempt print anyway
            fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - failed to load original into view for fallback: ${String(eLoad)}\n`);
          }
        }

        const printResult = await new Promise((resolve) => {
          tab.view.webContents.print({ silent: true, deviceName: printerName }, (success, failureReason) => {
            resolve({ success, failureReason });
          });
        });
        if (printResult && printResult.success) {
          addHistoryEntry({
            fileName: tab.title,
            printer: printerName,
            pages: pagesCount,
            copies: printOptions.copies
          });
          fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - webContents.print succeeded\n`);
          return { ok: true, advancedWarning, fallback: 'webcontents-print' };
        } else {
          const reason = (printResult && printResult.failureReason) || 'unknown';
          fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - webContents.print failed: ${reason}\n`);
          return { ok: false, error: `pdf-to-printer failed: ${errMsg}; webContents.print failed: ${reason}` };
        }
      } catch (e2) {
        fs.appendFileSync(PRINT_LOG_PATH, `${new Date().toISOString()} - webContents.print threw: ${String(e2)}\n`);
        return { ok: false, error: `pdf-to-printer failed: ${errMsg}; fallback error: ${String(e2)}` };
      }
    }
    return { ok: false, error: errMsg };
  }

  } finally {
    // Always restore the printer's previous global configuration if we
    // changed it for this job (N-up / DPI), no matter how printing ended.
    if (advResult && typeof advResult.restore === 'function') {
      try { await advResult.restore(); } catch (e) {}
    }
  }
}

// Diagnostic: list system printers and return statuses
ipcMain.handle('diagnose-printers', async () => {
  try {
    const [printers, statuses] = await Promise.all([getSystemPrinters(), getPrinterStatuses()]);
    return { ok: true, printers: printers.map(p => ({ name: p.name, displayName: p.name, status: statuses[p.name] || 'unknown' })) };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
});

// ---------- Printer status (Ready / Busy / Offline) ----------
// Windows has no universal ink-level API (that's vendor/driver specific),
// but PrinterStatus + WorkOffline from PowerShell's Get-Printer is reliable
// across manufacturers for ready/busy/offline state.
function getPrinterStatuses() {
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      [
        '-NoProfile',
        '-Command',
        'Get-Printer | Select-Object Name,PrinterStatus,WorkOffline | ConvertTo-Json'
      ],
      { timeout: 5000 },
      (err, stdout) => {
        if (err || !stdout) return resolve({});
        try {
          let parsed = JSON.parse(stdout);
          if (!Array.isArray(parsed)) parsed = [parsed];
          const map = {};
          for (const p of parsed) {
            let status = 'unknown';
            if (p.WorkOffline) status = 'offline';
            else if (p.PrinterStatus === 'Normal' || p.PrinterStatus === 0) status = 'ready';
            else if (p.PrinterStatus === 'Printing' || p.PrinterStatus === 'Processing') status = 'busy';
            else if (p.PrinterStatus) status = 'busy';
            map[p.Name] = status;
          }
          resolve(map);
        } catch (e) {
          resolve({});
        }
      }
    );
  });
}

function buildMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Open PDF...',
          accelerator: 'CmdOrCtrl+O',
          click: async () => {
            const result = await dialog.showOpenDialog(mainWindow, {
              properties: ['openFile', 'multiSelections'],
              filters: [{ name: 'PDF Files', extensions: ['pdf'] }]
            });
            for (const filePath of result.filePaths) {
              await createTab(filePath);
            }
          }
        },
        {
          label: 'Close Tab',
          accelerator: 'CmdOrCtrl+W',
          click: () => {
            if (activeTabId) closeTab(activeTabId);
          }
        },
        { type: 'separator' },
        {
          label: 'Print Active Tab',
          accelerator: 'CmdOrCtrl+P',
          click: () => sendToRenderer('trigger-print-active', {})
        },
        {
          label: 'Print All Tabs',
          accelerator: 'CmdOrCtrl+Shift+P',
          click: () => sendToRenderer('trigger-print-all', {})
        },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'View',
      submenu: [{ role: 'reload' }, { role: 'toggleDevTools' }]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ---------- IPC handlers ----------

ipcMain.handle('open-file-dialog', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'PDF Files', extensions: ['pdf'] }]
  });
  const ids = [];
  for (const filePath of result.filePaths) {
    const id = await createTab(filePath);
    if (id) ids.push(id);
  }
  return ids;
});

// pdf-lib can only embed JPEG and PNG — .gif/.bmp were previously accepted
// and then silently skipped when embedding failed.
const SUPPORTED_IMAGE_EXTS = ['.jpg', '.jpeg', '.png'];

// Merge image files into a single A4 PDF, preserving aspect ratio
// (images were previously stretched to fill the full page).
async function mergeImagesToPdf(imagePaths, title) {
  const pdfDoc = await PDFDocument.create();
  const A4_W = 595, A4_H = 842, MARGIN = 20;
  for (const imgPath of imagePaths) {
    try {
      const imgBuffer = await fs.promises.readFile(imgPath);
      const isPng = imgPath.toLowerCase().endsWith('.png');
      const image = isPng
        ? await pdfDoc.embedPng(imgBuffer).catch(() => pdfDoc.embedJpeg(imgBuffer))
        : await pdfDoc.embedJpeg(imgBuffer).catch(() => pdfDoc.embedPng(imgBuffer));
      const { width: iw, height: ih } = image.scale(1);
      const scale = Math.min((A4_W - MARGIN * 2) / iw, (A4_H - MARGIN * 2) / ih, 1e9);
      const w = iw * scale, h = ih * scale;
      const page = pdfDoc.addPage([A4_W, A4_H]);
      page.drawImage(image, { x: (A4_W - w) / 2, y: (A4_H - h) / 2, width: w, height: h });
    } catch (e) {
      console.error(`Error processing image ${imgPath}:`, e);
    }
  }
  if (pdfDoc.getPageCount() === 0) return null;
  const pdfBuffer = await pdfDoc.save();
  const mergedPath = path.join(os.tmpdir(), `print-shop-merged-${Date.now()}.pdf`);
  await fs.promises.writeFile(mergedPath, pdfBuffer);
  return createTab(mergedPath, { title });
}

ipcMain.handle('open-dropped-files', async (event, filePaths) => {
  const extractZip = require('extract-zip');
  const ids = [];
  const droppedImages = []; // images dropped directly (previously silently ignored)

  for (const filePath of filePaths) {
    const ext = path.extname(filePath).toLowerCase();
    
    if (ext === '.pdf') {
      // Regular PDF
      const id = await createTab(filePath);
      if (id) ids.push(id);
    } else if (ext === '.zip') {
      // Extract and process archive
      try {
        const tempDir = path.join(os.tmpdir(), `print-shop-${Date.now()}`);
        await extractZip(filePath, { dir: tempDir });
        
        // Find all images and PDFs
        const files = [];
        const walkDir = async (dir) => {
          const entries = await fs.promises.readdir(dir, { withFileTypes: true });
          for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            if (entry.isDirectory()) {
              await walkDir(fullPath);
            } else {
              const e = path.extname(entry.name).toLowerCase();
              if (e === '.pdf' || SUPPORTED_IMAGE_EXTS.includes(e)) {
                files.push(fullPath);
              }
            }
          }
        };
        
        await walkDir(tempDir);
        
        // Separate PDFs and images
        const pdfs = files.filter(f => f.toLowerCase().endsWith('.pdf'));
        const images = files.filter(f => SUPPORTED_IMAGE_EXTS.some(e => f.toLowerCase().endsWith(e)));
        
        // Open PDFs directly
        for (const pdf of pdfs.sort()) {
          const id = await createTab(pdf);
          if (id) ids.push(id);
        }
        
        // Merge images into a single PDF if any exist
        if (images.length > 0) {
          try {
            const id = await mergeImagesToPdf(images.sort(), `${path.basename(filePath, '.zip')} (merged images)`);
            if (id) ids.push(id);
          } catch (e) {
            console.error('Error merging images:', e);
          }
        }
      } catch (e) {
        console.error('Error extracting ZIP:', e);
      }
    } else if (SUPPORTED_IMAGE_EXTS.includes(ext)) {
      droppedImages.push(filePath);
    }
  }

  // Images dropped directly (outside a ZIP) — merge them into one PDF tab
  // instead of silently ignoring them like before.
  if (droppedImages.length > 0) {
    try {
      const title = droppedImages.length === 1
        ? path.basename(droppedImages[0])
        : `Images (${droppedImages.length} merged)`;
      const id = await mergeImagesToPdf(droppedImages, title);
      if (id) ids.push(id);
    } catch (e) {
      console.error('Error merging dropped images:', e);
    }
  }

  return ids;
});

// Cache printer statuses briefly — refreshPrinters() runs on every tab
// switch, and spawning a PowerShell process each time causes visible lag.
let printerStatusCache = { time: 0, data: {} };
async function getPrinterStatusesCached() {
  if (Date.now() - printerStatusCache.time < 10000) return printerStatusCache.data;
  const data = await getPrinterStatuses();
  printerStatusCache = { time: Date.now(), data };
  return data;
}

ipcMain.handle('get-printers', async () => {
  try {
    const [printers, statuses] = await Promise.all([getSystemPrinters(), getPrinterStatusesCached()]);
    return printers.map((p) => ({
      name: p.name,
      displayName: p.name,
      status: statuses[p.name] || 'unknown'
    }));
  } catch (e) {
    return [];
  }
});

ipcMain.handle('switch-tab', async (event, id) => switchTab(id));
ipcMain.handle('close-tab', async (event, id) => closeTab(id));
ipcMain.handle('duplicate-tab', async (event, id) => duplicateTab(id));
ipcMain.handle('toggle-tab-lock', async (event, id) => toggleLock(id));
ipcMain.handle('toggle-tab-pin', async (event, id) => togglePin(id));
ipcMain.handle('hide-tab', async (event, id) => hideTab(id));
ipcMain.handle('unhide-all-tabs', async () => unhideAllTabs());
ipcMain.handle('set-tab-bw', async (event, { id, bw }) => setTabBlackAndWhite(id, bw));

ipcMain.handle('set-tab-printer', async (event, { id, printer }) => {
  const tab = tabs.get(id);
  if (tab) tab.printer = printer;
  broadcastTabs();
});

ipcMain.handle('print-tab', async (event, { id, options }) => {
  const tab = tabs.get(id);
  if (tab && !options.confirmedLarge) {
    // Page counting is async after open — if the user prints immediately,
    // pageCount may still be 0 and the large-file warning would be skipped.
    // Count now (fast worker) before deciding.
    if (!tab.pageCount) {
      const count = await getPageCountFast(tab.originalFilePath || tab.filePath);
      const t = tabs.get(id);
      if (!t) return { ok: false, error: 'Tab closed' };
      t.pageCount = count;
      broadcastTabs();
    }
    if (tab.pageCount >= LARGE_FILE_WARNING_PAGES) {
      return { ok: false, needsConfirmation: true, pageCount: tab.pageCount };
    }
  }
  return printTab(id, options);
});

// Verbose print for diagnostics: returns full error message and stack if any
ipcMain.handle('verbose-print', async (event, { id, options }) => {
  try {
    const result = await printTab(id, options);
    return { ok: result.ok, result };
  } catch (e) {
    return { ok: false, error: String(e), stack: e && e.stack };
  }
});

ipcMain.handle('print-all-tabs', async (event, jobs) => {
  const results = [];
  for (const job of jobs) {
    const result = await printTab(job.id, job.options);
    results.push({ id: job.id, ...result });
  }
  return results;
});

ipcMain.handle('get-presets', () => store.get('presets'));

ipcMain.handle('save-preset', (event, preset) => {
  const presets = store.get('presets');
  presets.push({ id: `preset-${Date.now()}`, ...preset });
  store.set('presets', presets);
  return presets;
});

ipcMain.handle('delete-preset', (event, presetId) => {
  const presets = store.get('presets').filter((p) => p.id !== presetId);
  store.set('presets', presets);
  return presets;
});

ipcMain.handle('get-history', () => store.get('history'));

ipcMain.handle('clear-history', () => {
  store.set('history', []);
  return [];
});

ipcMain.handle('set-content-offset', (event, px) => {
  extraTopOffset = px || 0;
  layoutActiveView();
});

ipcMain.handle('get-language', () => store.get('language'));
ipcMain.handle('set-language', (event, lang) => {
  store.set('language', lang);
  return lang;
});

ipcMain.handle('get-theme', () => store.get('theme') || 'dark');
ipcMain.handle('set-theme', (event, theme) => {
  store.set('theme', theme);
  return theme;
});

ipcMain.handle('get-tabs-state', () => ({
  tabs: serializeTabs(),
  totalPages: getTotalPages()
}));

// ---------- Page filtering for preview ----------
// Creates a filtered PDF with only selected pages and returns its path
async function createFilteredPdfPreview(filePath, pageRangeText) {
  try {
    const buffer = await fs.promises.readFile(filePath);
    const doc = await PDFDocument.load(buffer, { ignoreEncryption: true });
    const totalPages = doc.getPageCount();
    
    // Parse page range (e.g., "1,3,5-7" -> [1,3,5,6,7])
    const pages = new Set();
    for (const part of pageRangeText.split(',')) {
      const trimmed = part.trim();
      if (!trimmed) continue;
      if (trimmed.includes('-')) {
        const [start, end] = trimmed.split('-').map(s => parseInt(s.trim(), 10));
        for (let i = start; i <= end && i <= totalPages; i++) {
          pages.add(i - 1); // 0-indexed
        }
      } else {
        const page = parseInt(trimmed, 10);
        if (page > 0 && page <= totalPages) pages.add(page - 1);
      }
    }
    
    if (pages.size === 0) return null;
    
    // Create new doc with only selected pages
    const newDoc = await PDFDocument.create();
    const sortedPages = Array.from(pages).sort((a, b) => a - b);
    
    for (const pageIdx of sortedPages) {
      const [copiedPage] = await newDoc.copyPages(doc, [pageIdx]);
      newDoc.addPage(copiedPage);
    }
    
    const filteredBuffer = await newDoc.save();
    
    // Save to temp file
    const tempDir = os.tmpdir();
    const hash = crypto.createHash('md5').update(filePath + pageRangeText).digest('hex').slice(0, 10);
    const tempPath = path.join(tempDir, `print-shop-preview-${hash}-${Date.now()}.pdf`);
    
    await fs.promises.writeFile(tempPath, filteredBuffer);
    return tempPath;
  } catch (e) {
    console.error('Error creating filtered PDF:', e);
    return null;
  }
}

ipcMain.handle('create-filtered-pdf-preview', async (event, { filePath, pageRangeText }) => {
  if (!pageRangeText || !pageRangeText.trim()) return { ok: false, error: 'Invalid page range' };
  const result = await createFilteredPdfPreview(filePath, pageRangeText);
  return result ? { ok: true, path: result } : { ok: false, error: 'Failed to create preview' };
});

// ---------- N-up (pages-per-sheet) preview ----------
// Compose N source pages onto a single A4 page for preview using pdf-lib
async function createNupPreview(filePath, pagesPerSheet, pageRangeText = null, maxPages = 500) {
  try {
    const buffer = await fs.promises.readFile(filePath);
    const srcDoc = await PDFDocument.load(buffer, { ignoreEncryption: true });
    const totalPages = srcDoc.getPageCount();

    // Determine pages to include
    let pagesToInclude = [];
    if (pageRangeText && pageRangeText.trim()) {
      const pages = new Set();
      for (const part of pageRangeText.split(',')) {
        const trimmed = part.trim();
        if (!trimmed) continue;
        if (trimmed.includes('-')) {
          const [start, end] = trimmed.split('-').map(s => parseInt(s.trim(), 10));
          for (let i = start; i <= end && i <= totalPages; i++) pages.add(i - 1);
        } else {
          const page = parseInt(trimmed, 10);
          if (page > 0 && page <= totalPages) pages.add(page - 1);
        }
      }
      pagesToInclude = Array.from(pages).sort((a,b) => a-b);
    } else {
      pagesToInclude = Array.from({length: totalPages}, (_,i) => i);
    }

    if (pagesToInclude.length === 0) return null;

    // Guard for very large docs — avoid composing thousands of pages into memory
    if (pagesToInclude.length > maxPages) {
      // Signal caller that document is too large for N-up preview
      return { error: 'too_large', totalPages };
    }

    const newDoc = await PDFDocument.create();

    // A4 dimensions in points (72 DPI): 595 x 842
    const PAGE_WIDTH = 595;
    const PAGE_HEIGHT = 842;

    // Grid for pagesPerSheet: support 1,2,4,6,9,16
    const gridMap = {
      1: [1,1],
      2: [2,1],
      4: [2,2],
      6: [3,2],
      9: [3,3],
      16: [4,4]
    };
    const grid = gridMap[pagesPerSheet] || [1,1];
    const cols = grid[0], rows = grid[1];

    const slotWidth = PAGE_WIDTH / cols;
    const slotHeight = PAGE_HEIGHT / rows;

    // Copy pages we need into the new doc as embedded pages
    const srcPages = await newDoc.copyPages(srcDoc, pagesToInclude);

    // Create pages grouping
    for (let i = 0; i < srcPages.length; i += cols*rows) {
      const page = newDoc.addPage([PAGE_WIDTH, PAGE_HEIGHT]);
      const chunk = srcPages.slice(i, i + cols*rows);
      for (let j = 0; j < chunk.length; j++) {
        const srcPage = chunk[j];
        // Calculate position
        const col = j % cols;
        const row = Math.floor(j / cols);
        const x = col * slotWidth;
        const y = PAGE_HEIGHT - (row + 1) * slotHeight; // PDF origin bottom-left

        // Embed the page as XObject and draw scaled to fit slot while preserving aspect
        const embedded = await newDoc.embedPage(srcPage);
        const { width: sw, height: sh } = embedded.scale(1);
        const xScale = Math.min(slotWidth / sw, slotHeight / sh);
        const drawWidth = sw * xScale;
        const drawHeight = sh * xScale;
        const dx = x + (slotWidth - drawWidth) / 2;
        const dy = y + (slotHeight - drawHeight) / 2;
        page.drawPage(embedded, { x: dx, y: dy, xScale: xScale, yScale: xScale });
      }
    }

    const outBuffer = await newDoc.save();
    const tempPath = path.join(os.tmpdir(), `print-shop-nup-${Date.now()}-${pagesPerSheet}.pdf`);
    await fs.promises.writeFile(tempPath, outBuffer);
    return { path: tempPath, sheets: newDoc.getPageCount() };
  } catch (e) {
    console.error('Error creating n-up preview:', e);
    return null;
  }
}

ipcMain.handle('create-nup-preview', async (event, { filePath, pagesPerSheet, pageRangeText }) => {
  if (!filePath) return { ok: false, error: 'No file' };
  const result = await createNupPreview(filePath, parseInt(pagesPerSheet,10) || 1, pageRangeText || null);
  if (!result) return { ok: false, error: 'Failed to create n-up preview' };
  if (result.error === 'too_large') return { ok: false, error: 'too_large', totalPages: result.totalPages };
  return { ok: true, path: result.path, sheets: result.sheets };
});

ipcMain.handle('load-pdf-in-active-tab', async (event, { filePath }) => {
  if (!activeTabId) return { ok: false, error: 'No active tab' };
  const tab = tabs.get(activeTabId);
  if (!tab) return { ok: false, error: 'Tab not found' };

  // Update the logical filePath for this tab so printing uses the shown document
  // If this is a temporary preview (nup/preview/merged) keep originalFilePath unchanged;
  // otherwise, set originalFilePath when it's not already set.
  const base = path.basename(filePath || '');
  const isTempPreview = /print-shop-(nup|preview|merged)-/.test(base);
  if (!isTempPreview && !tab.originalFilePath) {
    tab.originalFilePath = filePath;
  }
  tab.filePath = filePath;
  tab.isPreview = Boolean(isTempPreview);

  const fileUrl = pathToFileURL(filePath).href;
  try {
    if (!tab.view) {
      // Create a view if none (lazy) to show the preview
      const view = new BrowserView({ webPreferences: { plugins: true, contextIsolation: true, backgroundThrottling: true } });
      tab.view = view;
      mainWindow.addBrowserView(view);
      layoutActiveView();
    }
    await tab.view.webContents.loadURL(fileUrl);
  } catch (e) {
    console.error('Failed to load PDF in active tab:', e);
    return { ok: false, error: String(e) };
  }
  broadcastTabs();
  return { ok: true };
});

ipcMain.handle('load-original-in-active-tab', async () => {
  if (!activeTabId) return { ok: false, error: 'No active tab' };
  const tab = tabs.get(activeTabId);
  if (!tab) return { ok: false, error: 'Tab not found' };
  if (!tab.originalFilePath) return { ok: false, error: 'No original file saved' };
  tab.filePath = tab.originalFilePath;
  tab.isPreview = false;
  const fileUrl = pathToFileURL(tab.filePath).href;
  try {
    if (!tab.view) {
      const view = new BrowserView({ webPreferences: { plugins: true, contextIsolation: true, backgroundThrottling: true } });
      tab.view = view;
      mainWindow.addBrowserView(view);
      layoutActiveView();
    }
    await tab.view.webContents.loadURL(fileUrl);
  } catch (e) {
    console.error('Failed to load original PDF in active tab:', e);
    return { ok: false, error: String(e) };
  }
  broadcastTabs();
  return { ok: true };
});

// Remove temp artifacts (previews, n-up files, merged PDFs, extracted ZIPs,
// print tickets) — these previously accumulated in %TEMP% forever.
function cleanupTempFiles() {
  try {
    const tmp = os.tmpdir();
    for (const name of fs.readdirSync(tmp)) {
      if (name.startsWith('print-shop-') && name !== 'print-shop-print.log') {
        try {
          fs.rmSync(path.join(tmp, name), { recursive: true, force: true });
        } catch (e) {}
      }
    }
  } catch (e) {}
}

app.whenReady().then(createMainWindow);

app.on('before-quit', cleanupTempFiles);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
});
