let currentTabs = [];
let activeTabId = null;
const tabOptions = {}; // per-tab settings, mirrors Chrome's print dialog

const el = (id) => document.getElementById(id);

function defaultOptions() {
  return {
    copies: 1,
    color: 'color', // 'color' | 'bw'
    pagesMode: 'all', // 'all' | 'custom'
    pageRangeText: '',
    paperSize: 'A4',
    pagesPerSheet: 1,
    dpi: 0, // 0 = automatic/printer default, otherwise literal 300/600/1200
    scaleMode: 'fit-paper', // 'default' | 'fit-printable' | 'fit-paper' | 'custom'
    scaleCustom: 100,
    duplex: false,
    duplexFlip: 'long' // 'long' | 'short'
  };
}

let currentLang = 'en';

function renderTabs() {
  const list = el('tabs-list');
  list.innerHTML = '';
  // Hidden tabs are no longer rendered in the tab bar (previously "hide"
  // had no visible effect because this loop ignored the flag).
  const visibleTabs = currentTabs.filter((t) => !t.hidden);
  for (const tab of visibleTabs) {
    const div = document.createElement('div');
    div.className = 'tab' + (tab.active ? ' active' : '');

    // Build with textContent, NOT innerHTML — a PDF named
    // "<img src=x onerror=...>.pdf" would otherwise execute in the renderer.
    const titleSpan = document.createElement('span');
    titleSpan.className = 'tab-title';
    titleSpan.title = tab.title;
    if (tab.locked) {
      const lock = document.createElement('span');
      lock.className = 'tab-lock';
      lock.textContent = '🔒';
      titleSpan.appendChild(lock);
    }
    titleSpan.appendChild(document.createTextNode(`${tab.title} (${tab.pageCount})`));
    titleSpan.addEventListener('click', () => api.switchTab(tab.id));
    div.appendChild(titleSpan);

    if (!tab.locked) {
      const closeBtn = document.createElement('span');
      closeBtn.className = 'tab-close';
      closeBtn.textContent = '✕';
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        api.closeTab(tab.id);
        delete tabOptions[tab.id];
      });
      div.appendChild(closeBtn);
    }

    div.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showTabContextMenu(e.pageX, e.pageY, tab);
    });
    list.appendChild(div);
  }

  // If any tabs are hidden, show a chip to bring them all back
  const hiddenCount = currentTabs.length - visibleTabs.length;
  if (hiddenCount > 0) {
    const chip = document.createElement('div');
    chip.className = 'tab';
    chip.style.opacity = '0.7';
    chip.title = 'Show hidden tabs';
    chip.textContent = `👁 ${hiddenCount}`;
    chip.addEventListener('click', () => api.unhideAllTabs());
    list.appendChild(chip);
  }

  el('total-pages-count').textContent = String(
    currentTabs.reduce((sum, t) => sum + (t.pageCount || 0), 0)
  );
  el('empty-state').classList.toggle('hidden', visibleTabs.length > 0);
  el('dropzone-hint').style.display = visibleTabs.length > 0 ? 'none' : 'block';
}

function showTabContextMenu(x, y, tab) {
  const menu = el('tab-context-menu');
  menu.style.left = x + 'px';
  menu.style.top = y + 'px';
  menu.classList.remove('hidden');

  // Update dynamic labels
  const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
  const pinLabel = tab.pinned ? (dict.unpinTab || 'Unpin tab') : (dict.pinTab || 'Pin tab');
  const lockLabel = tab.locked ? (dict.unlockTab || 'Unlock tab') : (dict.lockTab || 'Lock tab');
  menu.querySelector('[data-action="pin"]').textContent = pinLabel;
  menu.querySelector('[data-action="lock"]').textContent = lockLabel;

  const onClick = (e) => {
    const action = e.target.getAttribute('data-action');
    if (action === 'duplicate') api.duplicateTab(tab.id);
    if (action === 'pin') api.toggleTabPin(tab.id);
    if (action === 'hide') api.hideTab(tab.id);
    if (action === 'lock') api.toggleTabLock(tab.id);
    if (action === 'close' && !tab.locked) {
      api.closeTab(tab.id);
      delete tabOptions[tab.id];
    }
    hideContextMenu();
  };
  menu.querySelectorAll('.context-item').forEach((item) => {
    item.onclick = onClick;
  });
}

function hideContextMenu() {
  el('tab-context-menu').classList.add('hidden');
}
document.addEventListener('click', hideContextMenu);

async function refreshPrinters(selectPrinter) {
  const printers = await api.getPrinters();
  const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
  const statusSymbol = { ready: '●', busy: '◐', offline: '✕', unknown: '○' };
  const statusLabel = {
    ready: dict.printerReady,
    busy: dict.printerBusy,
    offline: dict.printerOffline,
    unknown: dict.printerUnknown
  };
  const select = el('printer-select');
  select.innerHTML = '';
  for (const p of printers) {
    const opt = document.createElement('option');
    opt.value = p.name;
    const sym = statusSymbol[p.status] || statusSymbol.unknown;
    const label = statusLabel[p.status] || statusLabel.unknown;
    opt.textContent = `${sym} ${p.displayName || p.name} — ${label}`;
    select.appendChild(opt);
  }
  if (selectPrinter) select.value = selectPrinter;
}

function loadToolbarForActiveTab() {
  const opts = tabOptions[activeTabId] || defaultOptions();
  tabOptions[activeTabId] = opts;

  el('copies-input').value = opts.copies;
  el('color-select').value = opts.color;
  el('pages-mode-select').value = opts.pagesMode;
  el('pages-range-input').value = opts.pageRangeText;
  el('pages-range-input').classList.toggle('hidden', opts.pagesMode !== 'custom');
  el('paper-size-select').value = opts.paperSize;
  el('pages-per-sheet-select').value = String(opts.pagesPerSheet);
  el('quality-select').value = String(opts.dpi);
  el('scale-mode-select').value = opts.scaleMode;
  el('scale-custom-input').value = opts.scaleCustom;
  el('scale-custom-input').classList.toggle('hidden', opts.scaleMode !== 'custom');
  el('duplex-checkbox').checked = opts.duplex;
  el('duplex-flip-select').value = opts.duplexFlip;
  el('duplex-flip-select').classList.toggle('hidden', !opts.duplex);

  const tab = currentTabs.find((t) => t.id === activeTabId);
  refreshPrinters(tab ? tab.printer : null);
}

// Builds the payload sent to main for an actual print job
function buildPrintPayload(opts, printerOverride) {
  return {
    printer: printerOverride,
    copies: opts.copies,
    color: opts.color === 'color',
    pagesMode: opts.pagesMode,
    pageRangeText: opts.pageRangeText,
    paperSize: opts.paperSize,
    scaleMode: opts.scaleMode,
    duplex: opts.duplex,
    duplexFlip: opts.duplexFlip,
    pagesPerSheet: parseInt(opts.pagesPerSheet, 10) || 1,
    dpi: parseInt(opts.dpi, 10) || 0
  };
}

// ---------- Events from main process ----------

api.onTabsUpdated(({ tabs }) => {
  currentTabs = tabs;
  const newActive = tabs.find((t) => t.active);
  const activeChanged = newActive && newActive.id !== activeTabId;
  activeTabId = newActive ? newActive.id : null;
  renderTabs();
  if (activeChanged || (activeTabId && !tabOptions[activeTabId])) {
    loadToolbarForActiveTab();
  }
});

api.onTriggerPrintActive(() => printActiveTab());
api.onTriggerPrintAll(() => printAllTabs());

// ---------- Toolbar control changes persist per tab ----------

function bindOption(elementId, field, transform = (v) => v) {
  el(elementId).addEventListener('change', () => {
    if (!activeTabId) return;
    tabOptions[activeTabId][field] = transform(el(elementId).value);
  });
}

el('copies-input').addEventListener('change', () => {
  if (!activeTabId) return;
  tabOptions[activeTabId].copies = parseInt(el('copies-input').value, 10) || 1;
});
bindOption('color-select', 'color');
el('color-select').addEventListener('change', () => {
  if (!activeTabId) return;
  api.setTabBW(activeTabId, el('color-select').value === 'bw');
});
bindOption('paper-size-select', 'paperSize');
bindOption('pages-per-sheet-select', 'pagesPerSheet', (v) => parseInt(v, 10));
bindOption('quality-select', 'dpi', (v) => parseInt(v, 10) || 0);

// ---------- Live preview regeneration ----------
// One central function reads the CURRENT combination of options and rebuilds
// the view. Previously each control had its own partial handler, so e.g.
// switching "Pages: custom" back to "All", or changing the range while N-up
// was active, left the viewer stuck on the first preview it generated.
async function refreshPreview() {
  if (!activeTabId) return;
  const tab = currentTabs.find((t) => t.id === activeTabId);
  if (!tab) return;
  const opts = tabOptions[activeTabId] || defaultOptions();
  const source = tab.originalFilePath || tab.filePath;
  if (!source) return;

  const pagesPer = parseInt(opts.pagesPerSheet, 10) || 1;
  const range = (opts.pagesMode === 'custom' && opts.pageRangeText && opts.pageRangeText.trim())
    ? opts.pageRangeText.trim()
    : null;

  const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;

  if (pagesPer > 1) {
    const res = await api.createNupPreview({ filePath: source, pagesPerSheet: pagesPer, pageRangeText: range });
    if (res.ok) {
      await api.loadPdfInActiveTab(res.path);
    } else if (res.error === 'too_large') {
      showToast('Document too large for N-up preview — N-up will still be applied when printing.');
      if (tab.isPreview) await api.loadOriginalInActiveTab();
    } else {
      showToast('Failed to generate N-up preview');
    }
  } else if (range) {
    const res = await api.createFilteredPdfPreview(source, range);
    if (res.ok) {
      await api.loadPdfInActiveTab(res.path);
    }
  } else if (tab.isPreview) {
    // No transformation selected anymore — go back to the original document
    await api.loadOriginalInActiveTab();
  }
}

// Generate/refresh preview when pages-per-sheet changes
el('pages-per-sheet-select').addEventListener('change', () => {
  if (!activeTabId) return;
  refreshPreview();
});
bindOption('scale-custom-input', 'scaleCustom', (v) => parseInt(v, 10) || 100);
bindOption('duplex-flip-select', 'duplexFlip');

el('pages-mode-select').addEventListener('change', () => {
  const mode = el('pages-mode-select').value;
  el('pages-range-input').classList.toggle('hidden', mode !== 'custom');
  if (activeTabId) {
    tabOptions[activeTabId].pagesMode = mode;
    refreshPreview();
  }
});
el('pages-range-input').addEventListener('input', () => {
  if (!activeTabId) return;
  tabOptions[activeTabId].pageRangeText = el('pages-range-input').value;
});
el('pages-range-input').addEventListener('change', () => {
  if (!activeTabId) return;
  refreshPreview();
});
el('scale-mode-select').addEventListener('change', () => {
  const mode = el('scale-mode-select').value;
  el('scale-custom-input').classList.toggle('hidden', mode !== 'custom');
  if (activeTabId) tabOptions[activeTabId].scaleMode = mode;
});
el('duplex-checkbox').addEventListener('change', () => {
  const checked = el('duplex-checkbox').checked;
  el('duplex-flip-select').classList.toggle('hidden', !checked);
  if (activeTabId) tabOptions[activeTabId].duplex = checked;
});
el('printer-select').addEventListener('change', () => {
  if (!activeTabId) return;
  api.setTabPrinter(activeTabId, el('printer-select').value);
});

// ---------- More settings collapsible row ----------

function updateContentOffset() {
  const moreVisible = !el('more-settings').classList.contains('hidden');
  const extra = moreVisible ? el('more-settings').offsetHeight : 0;
  api.setContentOffset(extra);
  const top = 92 + extra;
  el('empty-state').style.top = top + 'px';
  el('history-panel').style.top = top + 'px';
}

el('more-settings-toggle').addEventListener('click', () => {
  el('more-settings').classList.toggle('hidden');
  updateContentOffset();
});

// ---------- Opening files ----------

el('new-tab-btn').addEventListener('click', () => api.openFileDialog());
el('empty-open-btn').addEventListener('click', () => api.openFileDialog());

// Drag & drop (only works over the tab bar / toolbar area — the PDF view
// itself is a native BrowserView and captures its own events)
for (const zoneId of ['tabbar', 'toolbar', 'empty-state']) {
  const zone = el(zoneId);
  zone.addEventListener('dragover', (e) => e.preventDefault());
  zone.addEventListener('drop', async (e) => {
    e.preventDefault();
    const paths = [];
    for (const file of e.dataTransfer.files) {
      const p = api.getPathForFile(file);
      if (p) paths.push(p);
    }
    if (paths.length) await api.openDroppedFiles(paths);
  });
}

// ---------- Printing ----------

function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 6000);
}

function setPrintButtonsBusy(busy) {
  for (const id of ['print-active-btn', 'print-all-btn']) {
    const btn = el(id);
    btn.disabled = busy;
    btn.classList.toggle('busy', busy);
  }
}

async function printActiveTab(confirmedLarge = false) {
  if (!activeTabId) return;
  const tab = currentTabs.find((t) => t.id === activeTabId);
  const opts = tabOptions[activeTabId] || defaultOptions();
  const options = buildPrintPayload(opts, tab ? tab.printer : el('printer-select').value);
  options.confirmedLarge = confirmedLarge;

  const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
  // Immediate feedback — the job (page counting, printer config, spooling)
  // can take several seconds; previously the button just sat there dead.
  setPrintButtonsBusy(true);
  showToast(dict.sendingPrint || TRANSLATIONS.en.sendingPrint || 'Sending print job…');

  let result;
  try {
    result = await api.printTab(activeTabId, options);
  } finally {
    setPrintButtonsBusy(false);
  }

  if (result.needsConfirmation) {
    showConfirmModal(result.pageCount, () => printActiveTab(true));
    return;
  }
  if (!result.ok) {
    showToast(`Print failed: ${result.error || 'Unknown error'}`);
    return;
  }
  if (result.advancedWarning) {
    const base = dict.advancedConfigWarning;
    showToast(`${base}\n${result.advancedWarning}`);
  } else {
    showToast(dict.printJobSent || TRANSLATIONS.en.printJobSent || 'Print job sent');
  }
}

async function printAllTabs() {
  // Hidden tabs are excluded from "Print all"
  const jobs = currentTabs.filter((t) => !t.hidden).map((t) => {
    const opts = tabOptions[t.id] || defaultOptions();
    const options = buildPrintPayload(opts, t.printer);
    options.confirmedLarge = true;
    return { id: t.id, options };
  });
  if (!jobs.length) return;

  const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
  setPrintButtonsBusy(true);
  showToast(dict.sendingPrint || TRANSLATIONS.en.sendingPrint || 'Sending print jobs…');

  let results;
  try {
    results = await api.printAllTabs(jobs);
  } finally {
    setPrintButtonsBusy(false);
  }

  const failed = results.filter((r) => !r.ok);
  if (failed.length) {
    const firstError = failed[0].error || 'Unknown error';
    showToast(`${results.length - failed.length}/${results.length} print jobs sent — ${failed.length} failed: ${firstError}`);
  } else {
    showToast(`All ${results.length} print jobs sent`);
  }

  const warned = results.find((r) => r.advancedWarning);
  if (warned) {
    const base = (TRANSLATIONS[currentLang] || TRANSLATIONS.en).advancedConfigWarning;
    showToast(`${base}\n${warned.advancedWarning}`);
  }
}

el('print-active-btn').addEventListener('click', () => printActiveTab());
el('print-all-btn').addEventListener('click', () => printAllTabs());

function showConfirmModal(pageCount, onConfirm) {
  const modal = el('confirm-modal');
  el('confirm-text').textContent = `هذا الملف فيه ${pageCount} صفحة. متأكد تريد تطبعه؟`;
  modal.classList.remove('hidden');
  const ok = el('confirm-ok-btn');
  const cancel = el('confirm-cancel-btn');
  const cleanup = () => {
    modal.classList.add('hidden');
    ok.removeEventListener('click', okHandler);
    cancel.removeEventListener('click', cancelHandler);
  };
  const okHandler = () => { cleanup(); onConfirm(); };
  const cancelHandler = () => cleanup();
  ok.addEventListener('click', okHandler);
  cancel.addEventListener('click', cancelHandler);
}

// ---------- Presets ----------

async function refreshPresetList() {
  const presets = await api.getPresets();
  const select = el('preset-select');
  select.innerHTML = '<option value="">— بدون —</option>';
  for (const p of presets) {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    select.appendChild(opt);
  }
  return presets;
}

el('preset-select').addEventListener('change', async () => {
  const presets = await api.getPresets();
  const preset = presets.find((p) => p.id === el('preset-select').value);
  if (!preset || !activeTabId) return;
  tabOptions[activeTabId] = { ...defaultOptions(), ...preset.options };
  loadToolbarForActiveTab();
  if (preset.printer) {
    api.setTabPrinter(activeTabId, preset.printer);
  }
});

el('save-preset-btn').addEventListener('click', () => {
  el('preset-modal').classList.remove('hidden');
  el('preset-name-input').value = '';
  el('preset-name-input').focus();
});
el('preset-cancel-btn').addEventListener('click', () => el('preset-modal').classList.add('hidden'));
el('preset-confirm-btn').addEventListener('click', async () => {
  const name = el('preset-name-input').value.trim();
  if (!name || !activeTabId) return;
  const tab = currentTabs.find((t) => t.id === activeTabId);
  await api.savePreset({
    name,
    options: tabOptions[activeTabId],
    printer: tab ? tab.printer : null
  });
  el('preset-modal').classList.add('hidden');
  await refreshPresetList();
});

// ---------- History ----------

el('history-btn').addEventListener('click', async () => {
  el('history-panel').classList.remove('hidden');
  await renderHistory();
});
el('close-history-btn').addEventListener('click', () => el('history-panel').classList.add('hidden'));
el('clear-history-btn').addEventListener('click', async () => {
  await api.clearHistory();
  await renderHistory();
});

async function renderHistory() {
  const history = await api.getHistory();
  const list = el('history-list');
  list.innerHTML = '';
  if (!history.length) {
    list.innerHTML = '<p style="color:#9aa0a6;font-size:12px;">لا يوجد سجل بعد</p>';
    return;
  }
  for (const h of history) {
    const div = document.createElement('div');
    div.className = 'history-item';
    const date = new Date(h.timestamp).toLocaleString('ar-IQ');
    // textContent — file/printer names must never be parsed as HTML
    const fileDiv = document.createElement('div');
    fileDiv.className = 'h-file';
    fileDiv.textContent = h.fileName;
    const metaDiv = document.createElement('div');
    metaDiv.className = 'h-meta';
    metaDiv.textContent = `${h.printer} • ${h.pages} صفحة × ${h.copies} نسخة • ${date}`;
    div.appendChild(fileDiv);
    div.appendChild(metaDiv);
    list.appendChild(div);
  }
}

el('language-select').addEventListener('change', async () => {
  currentLang = el('language-select').value;
  await api.setLanguage(currentLang);
  applyTranslations(currentLang);
  await refreshPrinters(el('printer-select').value);
});

// ---------- Theme switching ----------
function setTheme(themeName) {
  document.body.setAttribute('data-theme', themeName);
  api.setTheme(themeName);
}

el('theme-select').addEventListener('change', () => {
  setTheme(el('theme-select').value);
});

// ---------- Init ----------

(async function init() {
  currentLang = (await api.getLanguage()) || 'en';
  el('language-select').value = currentLang;
  applyTranslations(currentLang);

  // Load and apply theme
  const savedTheme = (await api.getTheme()) || 'dark';
  el('theme-select').value = savedTheme;
  setTheme(savedTheme);

  const state = await api.getTabsState();
  currentTabs = state.tabs;
  const active = currentTabs.find((t) => t.active);
  activeTabId = active ? active.id : null;
  renderTabs();
  await refreshPresetList();
  await refreshPrinters();
  updateContentOffset();
})();
