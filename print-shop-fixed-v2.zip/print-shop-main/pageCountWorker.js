const fs = require('fs');

// Usage: node pageCountWorker.js <filePath>
// Emits JSON to stdout: { count: N }
//
// Fixes vs. previous version:
// 1. The old pattern /\/Type\s*\/Page/ also matched "/Type /Pages" (the
//    page-TREE nodes), inflating the count. A negative lookahead now
//    requires the next char to not be a letter.
// 2. The 40-char leftover carried into the next chunk was re-scanned, so a
//    match landing inside it was counted twice. We now track each match's
//    absolute stream offset and dedupe.
// 3. A match ending exactly at a chunk boundary can't see its lookahead
//    char yet (it might be the 's' of "Pages"), so it is deferred to the
//    next iteration and settled in the final tail pass.
(async function () {
  const fp = process.argv[2];
  if (!fp) {
    console.error('No file path');
    process.exit(2);
  }
  let count = 0;
  const re = /\/Type\s*\/Page(?![A-Za-z])/g;
  const TAIL = 40; // enough to cover the pattern across a boundary
  try {
    const stream = fs.createReadStream(fp, { encoding: 'latin1' });
    let leftover = '';
    let absBase = 0;      // absolute offset of the current `data` start
    let lastCounted = -1; // absolute offset of the last counted match
    for await (const chunk of stream) {
      const data = leftover + chunk;
      for (const m of data.matchAll(re)) {
        if (m.index + m[0].length >= data.length) continue; // defer: lookahead char not visible yet
        const abs = absBase + m.index;
        if (abs > lastCounted) {
          count++;
          lastCounted = abs;
        }
      }
      const keep = Math.min(TAIL, data.length);
      leftover = data.slice(data.length - keep);
      absBase += data.length - keep;
    }
    // Final pass over the tail — end-of-string is a real EOF here, so the
    // lookahead is trustworthy.
    for (const m of leftover.matchAll(re)) {
      const abs = absBase + m.index;
      if (abs > lastCounted) {
        count++;
        lastCounted = abs;
      }
    }
    process.stdout.write(JSON.stringify({ count }));
    process.exit(0);
  } catch (e) {
    process.stdout.write(JSON.stringify({ count: 0, error: String(e) }));
    process.exit(0);
  }
})();
